<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
<?php echo $__env->yieldPushContent('js'); ?>
<script>
    var btnHover = document.querySelectorAll('.theme-btn');
    btnHover.forEach(function (btnHover) {
        if (typeof btnHover.firstChild.classList !== 'undefined' && Array.from(btnHover.firstChild.classList).includes('btn-text'))
        {
            btnHover.firstChild.innerHTML = btnHover.firstChild.textContent.replace(/([^\x00-\x80]|\w)/g, "<span class='btn_letters'>$&</span>");
            console.log(btnHover.firstChild.textContent)
        }
    });
    btnHover.forEach(function (btnHover) {
        btnHover.addEventListener('mouseenter', function () {
            var letter = btnHover.querySelectorAll('.btn_letters');
            // anime.timeline({}).add({
            //     targets: letter,
            //     translateY: ["1.1em", 0],
            //     translateZ: 0,
            //     duration: 750,
            //     delay: (el, i) => 50 * i
            // });
            anime({
                targets: letter,
                translateY: ["1.1em", 0],
                translateZ: 0,
                duration: 750,
                delay: (el, i) => 50 * i
            })
        });
    });
</script>
</html>
<?php /**PATH D:\xampp\htdocs\ultrra-shop\resources\views/layouts/app.blade.php ENDPATH**/ ?>